#include "asf.h"
#include "driver/include/m2m_wifi.h"
#include "driver/source/nmasic.h"
#include "adc_configure.h"
#include "adc_temp.h"

#define STRING_EOL    "\r\n"
#define STRING_HEADER "-- ese516 CLI example --"STRING_EOL \
"-- "BOARD_NAME " --"STRING_EOL	\
"-- Compiled: "__DATE__ " "__TIME__ " --"STRING_EOL
    uint8_t timeout=0;
	volatile offset = 0;
/* Structure for ADC module instance */
struct adc_module adc_instance;

/* Structure for USART module instance */
struct usart_module console_instance;

/*  To Store ADC output in voltage format */
float result;

/* To store raw_result of ADC output */
uint16_t raw_result;

/* To read the STATUS register of ADC */
uint8_t status;

// used for the conversion of user input pin to int for use in processing
int pin_value[10];


/// I2C

#define DATA_LENGTH 8
static uint8_t wr_buffer[DATA_LENGTH] = {
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07
};
static uint8_t rd_buffer[DATA_LENGTH];

#define SLAVE_ADDRESS (0x52>>1)
/// 0x52 0x53 0x29

struct i2c_master_module i2c_master_instance;

static struct i2c_master_packet wr_packet = {
	.address          = SLAVE_ADDRESS,
	.data_length      = DATA_LENGTH,
	.data             = wr_buffer,
	.ten_bit_address  = false,
	.high_speed       = false,
	.hs_master_code   = 0x00,
};

static struct i2c_master_packet rd_packet = {
	.address          = SLAVE_ADDRESS,
	.data_length      = DATA_LENGTH,
	.data             = rd_buffer,
	.ten_bit_address  = false,
	.high_speed       = false,
	.hs_master_code   = 0x00,
};

void configure_i2c(void)
{
	/* Initialize config structure and software module */
	struct i2c_master_config config_i2c_master;
	i2c_master_get_config_defaults(&config_i2c_master);
	/* Change buffer timeout to something longer */
	config_i2c_master.buffer_timeout    = 65535;
	config_i2c_master.pinmux_pad0       = PINMUX_PA08D_SERCOM2_PAD0;
	config_i2c_master.pinmux_pad1       = PINMUX_PA09D_SERCOM2_PAD1;
	config_i2c_master.generator_source  = GCLK_GENERATOR_0;
	/* Initialize and enable device with config */
	while(i2c_master_init(&i2c_master_instance, SERCOM2, &config_i2c_master) != STATUS_OK);
	i2c_master_enable(&i2c_master_instance);
}


/** UART module for debug. */
static struct usart_module cdc_uart_module;


/**
* \brief Configure UART console.
*/
static void configure_console(void)
{
	struct usart_config usart_conf;
	usart_get_config_defaults(&usart_conf);
	usart_conf.mux_setting = EDBG_CDC_SERCOM_MUX_SETTING;
	usart_conf.pinmux_pad0 = EDBG_CDC_SERCOM_PINMUX_PAD0;
	usart_conf.pinmux_pad1 = EDBG_CDC_SERCOM_PINMUX_PAD1;
	usart_conf.pinmux_pad2 = EDBG_CDC_SERCOM_PINMUX_PAD2;
	usart_conf.pinmux_pad3 = EDBG_CDC_SERCOM_PINMUX_PAD3;
	usart_conf.baudrate    = 115200;

	/// stdio_serial_init does usart_init + registers getchar and putchar, used by printf -- comment out to end up in Dummy Handler
	stdio_serial_init(&cdc_uart_module, EDBG_CDC_MODULE, &usart_conf);
	usart_enable(&cdc_uart_module);
}



/// some special ascii characters
#define CR '\r'
#define LF '\n'
#define BS '\b'
#define NULLCHAR '\0'
#define SPACE ' '

#define MAX_RX_BUFFER_LENGTH   100
volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];
uint8_t numberCharsRead;


bool processUserInput(void)
{
	char singleCharInput;
	volatile enum status_code uartReadCode = usart_read_buffer_wait(&cdc_uart_module, &singleCharInput, 1);
	if(STATUS_OK != uartReadCode)
	{
		return false;
	}
	if(STATUS_OK == uartReadCode)
	{
		volatile enum status_code uartWriteCode = usart_write_buffer_wait(&cdc_uart_module, &singleCharInput, 1);
	}
	
	switch (singleCharInput)
	{
		case CR:
		case LF:
		/// On carriage return (CR) or line feed (LF), the user has hit enter and it's time to process their command.
		/// Remember to null terminate your strings!  Otherwise, you could keep reading throughout memory.
		rx_buffer[numberCharsRead] = NULLCHAR;
		if(numberCharsRead > 0)
		{
			numberCharsRead = 0;
			return true;
		}
		break;
		
		case BS:
		/// User input a backspace -- remove the character
		numberCharsRead--;
		rx_buffer[numberCharsRead] = NULLCHAR;
		
		/// Feeling cheeky?  Do it all in one line
		// rx_buffer[--numberCharsRead] = NULLCHAR;
		break;

		default:
		/// All other cases
		if( numberCharsRead < MAX_RX_BUFFER_LENGTH )
		{
			rx_buffer[numberCharsRead++] = singleCharInput;
		}
		rx_buffer[numberCharsRead] = NULLCHAR;  ///< String read protection
		break;
	}
	return false;
	
	
}

void configure_pin()
{
	struct port_config config_port_pin;
	port_get_config_defaults(&config_port_pin);
	
	// set pin A17 & A23 (onboard LED) as output pins
 	config_port_pin.direction = PORT_PIN_DIR_OUTPUT;
 	port_pin_set_config(PIN_PA17, &config_port_pin);
	port_pin_set_config(LED_0_PIN, &config_port_pin);
	
	// set pin A16 & A19 as input pins
	config_port_pin.direction = PORT_PIN_DIR_INPUT;
	config_port_pin.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(PIN_PA16, &config_port_pin);
	port_pin_set_config(PIN_PA19, &config_port_pin);
}

void process_help()
{
	printf("List of functions:\r\n\
	** help: Prints all the available commands and a short synopsis.\r\n\
	** ver_bl: Prints the bootloader firmware version.\r\n\
	** ver_app: Prints the application code firmware version.\r\n\
	** gpio_set: Set a GPIO pin to high.\r\n\
	** gpio_clear: Set a GPIO pin to low.\r\n\
	** gpio_get: Get state of specified GPIO pin.\r\n\
	** mac: returns the mac address of the device.\r\n\
	** ip: returns the ip address of the device in the standard format: ex. 255.255.255.255\r\n\
	** read_temp_humid: Prints a number of readings at the given interval.\r\n\
	** adc_get: Get the ADC value of the given pin.\r\n\
	** mcu_temp: Prints the temperature of the mcu from the on-board temp sensor in celsius.\r\n\
	** i2c_scan: Prints out a list of addresses for devices on the I2C bus after scanning through all possible 7-bit combinations.\r\n");
}

/*
	// Description: Set a GPIO pin to high / 1
	// Inputs:
	//		Port: either �A� or �B�
	//		Pin number: number within the valid range
	// Outputs:
	//		Notes: if the pin/port is invalid, display an error with an appropriate message
	// Example: gpio_set A 15
	// Pick at least two pins to implement this functionality.  You need not implement for every pin.
	// http://asf.atmel.com/docs/3.35.1/samd21/html/asfdoc_sam0_port_basic_use_case.html
*/
void process_gpio_set(char port, int pin)
{
	if (port == 'A' && pin == 17)
	{
		port_pin_set_output_level(PIN_PA17, 1);
		printf("pin SET for A17 done\r\n");
	}
	
	else if (port == 'A' && pin == 23)
	{
		port_pin_set_output_level(LED_0_PIN, 0);
		printf("pin SET for LED done\r\n");
	}
	else
	{
		printf("Port & Pin combination not available for 'gpio_set'. Please select A17 or A23.\r\n");
	}
}


/**
 * Description: Set a GPIO pin to low / 0
 * Inputs:
 *		Port: either �A� or �B�
 *		Pin number: number within the valid range
 * Outputs:
 * Notes:  if the pin/port is invalid, display an error with an appropriate message
 * Example: gpio_clear A 15
 * Pick at least two pins to implement this functionality.  You need not implement for every pin.
 * http://asf.atmel.com/docs/3.35.1/samd21/html/asfdoc_sam0_port_basic_use_case.html
*/
void process_gpio_clear(char port, int pin)
{
	if (port == 'A' && pin == 17)
	{
		port_pin_set_output_level(PIN_PA17, 0);
		printf("pin CLEARED for A17 done\r\n");
	}
	
	else if (port == 'A' && pin == 23)
	{
		port_pin_set_output_level(LED_0_PIN, 1);
		printf("pin CLEARED for LED done\r\n");
	}
	else
	{
		printf("Port & Pin combination not available for 'gpio_clear'. Please select A17 or A23.\r\n");
	}
}

/*
// 	Description: Get state of specified GPIO pin
// 	Inputs:
// 	port: �A� or �B�
// 	Pin: valid pin number
// 	Outputs: 1 or 0 depending on the GPIO port pin�s register value
// 	Notes: if the pin/port is invalid, display an error with an appropriate message
// 	Example: gpio_get A 15
// 	Pick at least two pins to implement this functionality.  You need not implement for every pin.
*/
void process_gpio_get(char port, int pin)
{
		if (port == 'A' && pin == 17)
		{
			int n = port_pin_get_output_level(PIN_PA17);
			printf("get output level A17: %d\r\n", n);
		}
		
		else if (port == 'A' && pin == 23)
		{
			int n = port_pin_get_output_level(LED_0_PIN);
			printf("get output level LED: %d\r\n", n);
		}
		else
		{
			printf("Port & Pin combination not available for 'gpio_get'. Please select A17 or A23.\r\n");
		}

}

void process_mac()
{
	printf("dummy mac: xx-xx-xx-xx-xx-xx\r\n");
}

void process_ip()
{
	printf("dummy ip: 192.168.0.1\r\n");
}

void process_read_temp_humid()
{
	printf("dummy sensor reading: (something here)\r\n");
}


/**
* \brief ADC START and Read Result.
*
* This function starts the ADC and wait for the ADC
* conversation to be complete	and read the ADC result
* register and return the same to calling function.
*/
uint16_t adc_start_read_result(void)
{
	uint16_t adc_result = 0;
	
	adc_start_conversion(&adc_instance);
	while((adc_get_status(&adc_instance) & ADC_STATUS_RESULT_READY) != 1);
	
	adc_read(&adc_instance, &adc_result);
	
	return adc_result;
}


void process_adc_get(char port, int pin)
{
	int valid_flag = 0;
	
	// need to first set pin as input PIN_PA02, PIN_PA03
	struct port_config config_port_pin;
	port_get_config_defaults(&config_port_pin);
	
	config_port_pin.direction = PORT_PIN_DIR_INPUT;
	config_port_pin.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(PIN_PA02, &config_port_pin);
	port_pin_set_config(PIN_PA03, &config_port_pin);
	
	
	struct adc_config conf_adc;
	
	adc_get_config_defaults(&conf_adc);
	
	conf_adc.clock_source = GCLK_GENERATOR_1;
	conf_adc.clock_prescaler = ADC_CLOCK_PRESCALER_DIV16;
	conf_adc.reference = ADC_REFERENCE_INTVCC1;
	conf_adc.negative_input = ADC_NEGATIVE_INPUT_GND;
	conf_adc.sample_length = ADC_TEMP_SAMPLE_LENGTH;
	
	if (port == 'A' && pin == 2)
	{
		conf_adc.positive_input = ADC_POSITIVE_INPUT_PIN0; //go to implementation: this pin is designated as AIN[0], which is PA02. check section 5.1 multiplexing section of manual.
		valid_flag = 1;
	}
	else if (port == 'A' && pin == 3)
	{
		conf_adc.positive_input = ADC_POSITIVE_INPUT_PIN1; //AIN[1] is PA03.
		valid_flag = 1;
	}
	
	if (valid_flag == 1) 
	{
			adc_init(&adc_instance, ADC, &conf_adc);
			ADC->AVGCTRL.reg = ADC_AVGCTRL_ADJRES(2) | ADC_AVGCTRL_SAMPLENUM_4;
			adc_enable(&adc_instance);
			raw_result = adc_start_read_result();
			
			printf("ADC conversion: %d\r\n", raw_result);
	}
	else
	{
		printf("Port & Pin combination not available for 'adc_get'. Please choose A2 or A3.\r\n");
		valid_flag = 0;
	}

}


/**
* \brief ADC internal TemperatureSensor mode.
*
* This function enables the internal temperature sensor for ADC input and displays
* the current room temperature in serial console after the calculation done using ADC result.
*/
void adc_temp_sensor(void)
{
	float temp;
	
	system_voltage_reference_enable(SYSTEM_VOLTAGE_REFERENCE_TEMPSENSE);
	
	configure_adc_temp();
	
	load_calibration_data();
	
	raw_result = adc_start_read_result();
	printf("raw_result is: %d\r\n", raw_result);
	
	temp = calculate_temperature(raw_result);
	
	printf("\nThe current temperature is = %f degree Celsius\r\n", temp);
	
}

int power(int i,int j) //implemented by Alan
{
	int a=i;
	i=1;
	for(int q=0; q < j; q++)
	{
		i =i*a;
	}
	return i;
}


/// At this point, we have taken in a string.  We need to parse it for its arguments.
/// Example:  Input: "help" -- 1 argument ("help")
/// Example:  Input: "gpio_set A 15" -- 3 arguments ("gpio_set", "A", "15")
void processCommand(void)
{
	printf("\r\nYour entered command was: ");
	printf(rx_buffer);
	printf("\r\n");
	
	/// Max number of arguments -- including the command itself
	#define MAX_ARGS 4
	
	/// strpbrk - parse arguments (space delimited)
	/// http://www.cplusplus.com/reference/cstring/strpbrk/
	#define DELIMITER " "
	int16_t nargs = 0;
	char *midStringPtr;
	char *arguments[MAX_ARGS];
	arguments[nargs++] = rx_buffer;
	midStringPtr = strpbrk(rx_buffer, DELIMITER); //strpbrk finds the first character in the string str1 that matches any character specified in str2. char *strpbrk(const char *str1, const char *str2)
	while (midStringPtr != NULL) {
		arguments[nargs] = midStringPtr+1;
		*midStringPtr = '\0';
		midStringPtr = strpbrk(arguments[nargs], DELIMITER);
		nargs++;
 	}
/*gpio_set*/
	int8_t found = 0;
	
	char* cmd = arguments[0];
	char port = *arguments[1];
	char* pin =  arguments[2];
	int count=0;
	int i=0;
	
	///////////////////////////
	//this part converts the pin value into an INT
	
	while(pin[i] != '\0')
	{
		count++;
		pin_value[i] = (int)pin[i]-48;
		i++;
	}
	//printf("count value is: %d,test:%d\r\n", count,power(10,2));
	
	int final_pin = 0; 
	for(int j=0;j<count;j++)
	{
		final_pin +=pin_value[j] * power(10,(count-j-1));
	}
	///////////////////////////
	///////////////////////////

	//https://stackoverflow.com/questions/37224829/printing-strings-from-an-array-in-a-function-in-c
		
	//printf("port is: %c\r\n\t, pin is: %d\r\n\r\n", port, final_pin);
	
	
	if (0 == strcmp("help", rx_buffer)) { //if Return value = 0 then it indicates str1 is equal to str2.
		process_help();
		found = 1;
		
		} else if (0 == strcmp("ver_bl", rx_buffer)) {
			uint8 MAJOR = 0;
			uint8 MINOR = 0;
			uint8 PATCH = 0;
			int alpha = 1; //alpha versioning local variable
			
			if (alpha == 0)
			{
				printf("bootloader version: %d.%d.%d", MAJOR, MINOR, PATCH);
				found = 1;
			} else
			{
				printf("bootloader version: %d.%d.%d-alpha", MAJOR, MINOR, PATCH);
				found = 1;
			}

		} else if (0 == strcmp("ver_app", rx_buffer)) {
			uint8 MAJOR = 0;
			uint8 MINOR = 0;
			uint8 PATCH = 0;
			int alpha = 1; //alpha versioning local variable
			
			if (alpha == 0)
			{
				printf("application version: %d.%d.%d", MAJOR, MINOR, PATCH);
				found = 1;
			} else
			{
				printf("application version: %d.%d.%d-alpha", MAJOR, MINOR, PATCH);
				found = 1;
			}
			
		} else if (0 == strcmp("gpio_set", rx_buffer)) {

			process_gpio_set(port, final_pin);
			
// for debugging
// 			if (0 == strcmp("25", pin))
// 			{
// 				printf("PIN MATCHES!!");
// 			}

			found = 1;

		} else if (0 == strcmp("gpio_clear", rx_buffer)) {
			process_gpio_clear(port, final_pin);
			found = 1;

		} else if (0 == strcmp("gpio_get", rx_buffer)) {
			process_gpio_get(port, final_pin);
			found = 1;

		} else if (0 == strcmp("mac", rx_buffer)) {
			process_mac();
			found = 1;
			
		} else if (0 == strcmp("ip", rx_buffer)) {
			process_ip();
			found = 1;
			
		} else if (0 == strcmp("read_temp_humid", rx_buffer)) {
			process_read_temp_humid();
			found = 1;

		} else if (0 == strcmp("adc_get", rx_buffer)) {
			process_adc_get(port, final_pin);
			found = 1;
			
		} else if (0 == strcmp("mcu_temp", rx_buffer)) {
			adc_temp_sensor();
			found = 1;
			
		} else if (0 == strcmp("i2c_scan", rx_buffer)) {
			
	enum status_code i2c_status;
	wr_packet.address     = SLAVE_ADDRESS;
	wr_packet.data_length = 1;
	wr_buffer[0]          = 0xC0;
	wr_packet.data        = wr_buffer;
	bool flag=1;
	while(flag)
	{
		while((i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet))==STATUS_OK)
		{
			printf("slave address:0X%x",wr_packet.address);
			flag=0;
			offset=0;
			break;
		}
		timeout++;
		if(timeout==200)
		{
			timeout=0;
			offset++;
			wr_packet.address = SLAVE_ADDRESS+offset;
		}
	}
	found=1;
}

	/// If we don't find any commands, print an error
	if (!found) printf("ERROR: Unknown command\r\n");
	
	/// Space things out a bit
	printf("\r\n\r\n");
	
}


int main(void)
{

	/* Initialize the board. */
	system_init();
	system_interrupt_enable_global();

	/**
	* https://gist.github.com/vdemay/516e7dd7075781bbef0b
	* check port.h
	* used for initialization of GPIO port/pins
	*/
	// 	struct port_config pin_conf;
	// 	port_get_config_defaults(&pin_conf);


	/* Initialize the UART console. */
	configure_console();
	printf("\r\n\r\n\r\n");
	printf(STRING_HEADER);
	
	/* Initialize I2C */
	configure_i2c();
	
	enum status_code i2c_status;
	wr_packet.address     = SLAVE_ADDRESS;
	wr_packet.data_length = 1;
	wr_buffer[0]          = 0xC0;
	wr_packet.data        = wr_buffer;
	i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet);
	if( i2c_status == STATUS_OK ){ i2c_status = i2c_master_read_packet_wait(&i2c_master_instance, &rd_packet); }
	i2c_master_send_stop(&i2c_master_instance);
	
	wr_buffer[0]          = 0xC1;
	wr_packet.data        = wr_buffer;
	i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet);
	if( i2c_status == STATUS_OK ){ i2c_status = i2c_master_read_packet_wait(&i2c_master_instance, &rd_packet); }
	i2c_master_send_stop(&i2c_master_instance);
	
	wr_buffer[0]          = 0xC2;
	wr_packet.data        = wr_buffer;
	i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet);
	if( i2c_status == STATUS_OK ){ i2c_status = i2c_master_read_packet_wait(&i2c_master_instance, &rd_packet); }
	i2c_master_send_stop(&i2c_master_instance);
	
	wr_buffer[0]          = 0x51;
	wr_packet.data        = wr_buffer;
	i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet);
	if( i2c_status == STATUS_OK ){ i2c_status = i2c_master_read_packet_wait(&i2c_master_instance, &rd_packet); }
	i2c_master_send_stop(&i2c_master_instance);
	
	wr_buffer[0]          = 0x61;
	wr_packet.data        = wr_buffer;
	i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet);
	if( i2c_status == STATUS_OK ){ i2c_status = i2c_master_read_packet_wait(&i2c_master_instance, &rd_packet); }
	i2c_master_send_stop(&i2c_master_instance);
	
	
	configure_pin();
	
	while (1) {
		
		/// Handle the serial input until user hits "Enter"
		/// When a full command has been entered (known by CR LF), process the command
		bool commandEntered = processUserInput();
		if(commandEntered)
		{
			printf("\r\n...command has been entered...");
			processCommand();
		}
		

	}
	return 0;
}

