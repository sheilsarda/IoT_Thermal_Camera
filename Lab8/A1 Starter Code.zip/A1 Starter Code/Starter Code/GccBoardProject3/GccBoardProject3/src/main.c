/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * This is a bare minimum user application template.
 *
 * For documentation of the board, go \ref group_common_boards "here" for a link
 * to the board-specific documentation.
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to system_init()
 * -# Basic usage of on-board LED and button
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include "SerialConsole/SerialConsole.h"
#include "main.h"





#define MAX_RX_BUFFER_LENGTH   5

#define REG_ADDR_LENGTH 1
static uint8_t wr_buffer[REG_ADDR_LENGTH] = {
	0x00
};

#define DATA_LENGTH 2
static uint8_t rd_buffer[DATA_LENGTH];

#define SLAVE_ADDRESS (0x69>>1)

struct i2c_master_module i2c_master_instance;

static struct i2c_master_packet wr_packet = {
	.address          = SLAVE_ADDRESS,
	.data_length      = REG_ADDR_LENGTH,
	.data             = wr_buffer,
	.ten_bit_address  = false,
	.high_speed       = false,
	.hs_master_code   = 0x00,
};

static struct i2c_master_packet rd_packet = {
	.address          = SLAVE_ADDRESS,
	.data_length      = DATA_LENGTH,
	.data             = rd_buffer,
	.ten_bit_address  = false,
	.high_speed       = false,
	.hs_master_code   = 0x00,
};

void configure_i2c(void)
{
	/* Initialize config structure and software module */
	struct i2c_master_config config_i2c_master;
	i2c_master_get_config_defaults(&config_i2c_master);
	/* Change buffer timeout to something longer */
	config_i2c_master.buffer_timeout    = 65535;
	config_i2c_master.pinmux_pad0       = PINMUX_PA08D_SERCOM2_PAD0;
	config_i2c_master.pinmux_pad1       = PINMUX_PA09D_SERCOM2_PAD1;
	config_i2c_master.generator_source  = GCLK_GENERATOR_0;
	/* Initialize and enable device with config */
	while(i2c_master_init(&i2c_master_instance, SERCOM2, &config_i2c_master) != STATUS_OK);
	i2c_master_enable(&i2c_master_instance);
}

volatile uint8_t rx_buffer[MAX_RX_BUFFER_LENGTH];

volatile char buffer[7];

int16_t getRegister(unsigned char reg){
//	int16_t result;
	enum status_code i2c_status;

	wr_buffer[0]          = reg;
	wr_packet.data        = wr_buffer;
	wr_packet.address     = SLAVE_ADDRESS;

	i2c_status = i2c_master_write_packet_wait_no_stop(&i2c_master_instance, &wr_packet);
	
// 	
// 	if( i2c_status == STATUS_OK ){ i2c_status = i2c_master_read_packet_wait(&i2c_master_instance, &rd_packet); }
// 
// 	i2c_master_send_stop(&i2c_master_instance);
// 	result = (uint16_t)rd_packet.data[1] << 8 | rd_packet.data[0];
//	return result;

}

int main (void)
{
	//Board Initialization -- Code that initializes the HW and happens only once
	system_init();
	InitializeSerialConsole();

	/* Insert application code here, after the board has been initialized. */


	system_interrupt_enable_global();
	
	SerialConsoleWriteString("ESE516 - CLI and Debug Logger\r\n");	//Order to add string to TX Buffer
	
	char string[] = "CLI starter code - ESE516\r\n";
	
	/*Simple DebugLogger Test*/
	setLogLevel(LOG_INFO_LVL); 
	LogMessage(LOG_INFO_LVL , "%s", string); //Test
	setLogLevel(LOG_ERROR_LVL); //Sets the Debug Logger to only allow messages with LOG_ERROR_LVL or higher to be printed
	LogMessage(LOG_INFO_LVL, "Performing Temperature Test�\r\n"); //This should NOT print
	LogMessage(LOG_FATAL_LVL,"Error! Temperature over %d Degrees!\r\n", 55); //This should print

	configure_i2c();

	/* This skeleton code simply sets the LED to the state of the button. */
	while (1) {

		/* Is button pressed? */
		if (port_pin_get_input_level(BUTTON_0_PIN) == BUTTON_0_ACTIVE) {
			/* Yes, so turn LED on. */
			port_pin_set_output_level(LED_0_PIN, LED_0_ACTIVE);
			getRegister(AVERAGE_REGISTER);
		} else {
			/* No, so turn LED off. */
			port_pin_set_output_level(LED_0_PIN, !LED_0_ACTIVE);
		}


		//At the very end of the system, we tell the MCU to handle the text that is currently on the RX buffer
		//Put a call to your state machine code that will handle the CLI by reading the data
		//present on the RX buffer.

	}
}
